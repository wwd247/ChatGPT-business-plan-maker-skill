# Business Plan Maker for ChatGPT

This package is the ChatGPT adaptation of the Claude Business Plan Maker workflow.

## Contents

- `business-plan-maker/SKILL.md` — ChatGPT skill instructions.
- `business-plan-maker/assets/reference_template.docx` — the original Word template used as the structure and formatting reference.

## Installation

Where ChatGPT Skills are enabled for your account/workspace:

1. Open **Plugins** in ChatGPT.
2. Open the **Skills** tab.
3. Choose **Create** and then **Upload from your computer**.
4. Upload this ZIP file.
5. Review the skill and install/enable it.

You can then start a new chat and ask for a business plan. ChatGPT should use the skill when the request matches its description.

## Important availability note

As of September 2026, OpenAI documents ChatGPT Skills as available to eligible Business, Enterprise, Healthcare, and Edu users, subject to workspace settings and product availability. If a client's ChatGPT account does not show the Skills area, the same workflow can instead be adapted to another supported reusable-workflow surface available to that account.

## Behaviour

The skill interviews the user in a few concise batches, uses the answers to draft the plan in the bundled template's structure, conditionally handles outside-investment/IPO language, labels assumptions rather than inventing financial facts, writes the Executive Summary last, and outputs an editable Word document.

---
name: business-plan-maker
description: Creates a complete, polished business plan as an editable Word (.docx) document using the bundled reference template. Use when a user asks to create, draft, write, revise, expand, or formalize a business plan, or wants to turn a business idea into a structured plan. Interview the user in concise batched passes, then populate the template's structure with their answers. Preserve the template's section order and intent, handle funding-path language conditionally, avoid presenting invented financials or market facts as verified, and write the Executive Summary last.
---

# Business Plan Maker

Use this skill to interview a user about a business and turn the answers into a complete Word business plan based on `assets/reference_template.docx`.

## Core behavior

- Treat the bundled Word file as the authoritative structural and formatting reference.
- Before drafting, inspect the template and identify its exact sections, subsections, tables, prompts, and any conditional wording. Do not rely only on this SKILL.md summary when the template can be read directly.
- Check the current conversation and any user-provided files first. Never ask again for information the user has already supplied.
- Ask questions in a small number of useful batches, not one question at a time and not as one overwhelming questionnaire.
- Keep the interview conversational and adapt follow-up questions to the business rather than mechanically asking irrelevant questions.
- Do not draft the final Word document until enough information has been gathered, unless the user explicitly asks for a quick/placeholder draft.

## Workflow

### 1. Gather company basics

Ask for missing essentials such as:
- Business/company name.
- One-sentence description of what it does.
- Country/market of operation when relevant to the plan.
- Legal structure, if known.
- Founder(s), owner(s), or major shareholder(s), where relevant.
- Industry/sector.
- Primary target customers or market.

If the user does not yet know a legal structure or similar detail, do not force a choice. Mark it as to be confirmed or use a clearly labelled placeholder.

### 2. Gather strategy and commercial model

Ask for missing information needed by the template, including as applicable:
- Mission and vision.
- Customer problem and proposed solution.
- Unique selling proposition / competitive advantage.
- Products and/or services.
- Revenue streams.
- Pricing for each distinct revenue stream.
- Known competitors. Do not invent named competitors as verified facts.
- Brand/market positioning.
- Routes to market / distribution channels.
- Marketing and sales approach.
- Short-, medium-, and long-term goals.
- Key operational requirements, suppliers, facilities, technology, staffing, and partnerships where relevant.

If useful information is missing after the first strategy batch, ask one focused follow-up batch rather than silently filling important gaps.

### 3. Determine the funding path

Ask directly whether the business is:
- self-funded / owner-operated / privately held with no current outside-investment plan;
- seeking a bank loan or other debt funding;
- seeking outside equity investment; or
- pursuing an IPO/public-market path.

Use this answer to control any conditional investment/IPO wording in the template. If the template contains bracketed instructions such as "include if pursuing outside investment/IPO", remove the instructional brackets in the finished plan and include the enclosed substance only when it actually applies. Otherwise omit both the instruction and its conditional content.

For a bank-loan plan, collect the amount requested, intended use of funds, proposed repayment source, and any known repayment assumptions when these are available.

### 4. Gather financial inputs

Ask for the financial information the user actually has, such as:
- Startup/setup costs.
- Current revenue, if trading already.
- Unit prices or average transaction values.
- Cost of goods/services or gross-margin assumptions.
- Payroll/staffing costs.
- Rent, software, marketing, logistics, professional fees, and other recurring costs.
- Expected sales volumes or customer numbers.
- Funding requirement and use of funds.
- Forecast horizon requested by the user or required by the template.

Never present invented precise figures as facts. If the user lacks figures, offer to build an illustrative model using clearly labelled assumptions. Every modelled figure that is not user-supplied or externally verified must be identifiable as an estimate/assumption.

If the user explicitly says to make reasonable assumptions, placeholders, or a fast draft, do so without extending the interview unnecessarily, but label assumptions clearly.

### 5. Draft sections 2 onward first

Follow `assets/reference_template.docx` section-by-section and subsection-by-subsection, preserving its heading hierarchy, order, purpose, and overall professional voice.

Where the template contains questions or instructional prompts for the future author, replace them with business-specific prose based on the interview. Do not leave authoring questions in the final plan unless the user specifically requests an unfinished worksheet/template.

Prefer the user's terminology, business model, and stated facts over generic boilerplate. Keep the plan concrete and specific.

Do not invent market-size statistics, regulatory claims, named competitors, customer contracts, partnerships, traction, certifications, or financial history as verified facts. If outside research is requested and web access is available, research those items and distinguish sourced facts from projections and assumptions.

### 6. Write the Executive Summary last

Do not ask the user to write the Executive Summary.

After the rest of the plan has been drafted, synthesize the Executive Summary from the completed sections. Keep it concise enough to function as an executive overview and include, where relevant:
- What the company does.
- The problem/opportunity.
- Target market.
- Main products/services.
- USP/competitive position.
- Commercial model.
- Key milestones/strategy.
- High-level financial outlook.
- Funding request and use of funds, if applicable.

For bank-loan plans, include the borrowing amount, purpose, and repayment basis if the user supplied them.

### 7. Produce the Word document

Create the final deliverable as an editable `.docx`.

Use the bundled `assets/reference_template.docx` as the starting point whenever the available document tools permit direct editing. Preserve the template's page setup, styles, fonts, colors, heading hierarchy, tables, headers/footers, spacing, and visual identity as closely as possible while replacing instructional/template content with the completed plan.

If direct in-place population is not possible in the current ChatGPT surface, recreate the document using the template as the visual and structural reference rather than silently switching to an unrelated design.

Before delivery, perform a final document-quality check for:
- Missing or duplicated sections.
- Unanswered template prompts.
- Placeholder text that should have been replaced.
- Contradictory names, dates, locations, ownership, or funding path.
- Unsupported precise financial claims.
- Tables that do not reconcile with narrative figures.
- Broken pagination, clipped text, malformed tables, or obvious formatting drift when rendering/preview tools are available.

Deliver the `.docx` to the user with a concise note that projections and assumptions should be validated before external use.

### 8. Revisions

If the user later asks for changes, revise the existing generated business plan rather than starting from scratch. Preserve unchanged content and formatting unless the requested change requires otherwise.

## Interaction style

- Be efficient and professional.
- Prefer 4-8 related questions in a batch when information is missing.
- Explain briefly why a question matters only when clarification would help the user answer it.
- Do not make the user complete a long form when the same information can be collected naturally over a few turns.
- If the user has already supplied a detailed brief or an existing plan, extract answers from it first and ask only for genuine gaps.

## Final safeguards

- Separate facts, user-supplied figures, externally verified information, and assumptions.
- Never disguise assumptions as historical results.
- Never fabricate investor commitments, customer contracts, licenses, regulatory approvals, or market research.
- A generated business plan is a drafting aid, not legal, accounting, investment, tax, or regulatory advice.
